﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1
{
    class Factory
    {
       
        public void DoProcess()
        {
            var person = new Person();
        }

    }
}
